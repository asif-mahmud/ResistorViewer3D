from PyQt4.QtCore import *
from PyQt4.QtGui import *

from parent_dialog.parent_dialog import Parent
import icon_rc

class ResViewer(QMainWindow):
    '''It is the Main class'''

    def __init__(self,parent=None):
        super(ResViewer,self).__init__(parent)

        self.mainWidget = Parent()

        self.setCentralWidget(self.mainWidget)

        screen = QDesktopWidget().screenGeometry()
        w=435
        h=575
        self.move((screen.width()-w)/2,(screen.height()-h)/2)
        self.setFixedSize(self.sizeHint())

        self.setWindowTitle("Resistor Viewer 3D")
        self.setWindowIcon(QIcon("icon.png"))

        
