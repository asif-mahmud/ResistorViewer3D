from PyQt4.QtCore import *
from PyQt4.QtGui import *


from res_viewer.res_viewer import ResViewer
from colors import colors

class Parent(QDialog):

    def __init__(self,parent =None):
        super(Parent,self).__init__(parent)

        self.resViewer = ResViewer()
        
        self.__4band = QCheckBox("4 Colors")
        self.__4band.setChecked(True)
        self.__5band = QCheckBox("5 Colors")
        self.__credit = QPushButton("Credit")
        self.__credit.setMaximumWidth(50)
        
        self.selectBand = QHBoxLayout()
        self.selectBand.addWidget(self.__4band)
        self.selectBand.addWidget(self.__5band)
        self.selectBand.addWidget(self.__credit)

        self.l1 = QLabel("<font color =blue>Select the Color(seriouly) of the Band and hit Go :</font>")

        self.__1stColor = QComboBox()
        self.__1stColor.addItems(colors.ColorNames1)
        self.__2ndColor = QComboBox()
        self.__2ndColor.addItems(colors.ColorNames1)
        self.__3rdColor = QComboBox()
        self.__3rdColor.addItems(colors.ColorNames2)
        self.__4thColor = QComboBox()
        self.__4thColor.addItems(colors.ColorNames2)
        self.__5thColor = QComboBox()
        self.__5thColor.addItems(colors.ColorNames2)
        self.__5thColor.setEnabled(False)

        self.__go1 = QPushButton("Go")
        self.__go1.setMaximumWidth(25)

        self.selCol = QHBoxLayout()
        self.selCol.addWidget(self.__1stColor)
        self.selCol.addWidget(self.__2ndColor)
        self.selCol.addWidget(self.__3rdColor)
        self.selCol.addWidget(self.__4thColor)
        self.selCol.addWidget(self.__5thColor)
        self.selCol.addWidget(self.__go1)


        self.l2 = QLabel("<font color =blue>Type the value of resistor in Ohm and hit Go :<br>You have to select tolerance from the last color band</font>")

        self.__textValue = QLineEdit("")
        self.l3 = QLabel("<font>+\-</font>")
        self.__textTolerance = QLineEdit("")
        self.l4 = QLabel("<font>%</font>")
        self.__go2 = QPushButton("Go")

        self.__textTolerance.setReadOnly(True)

        self.__textValue.setText(QString.number(0))
        self.__textTolerance.setText(QString.number(0))

        self.textVal = QHBoxLayout()

        self.textVal.addWidget(self.__textValue)
        self.textVal.addWidget(self.l3)
        self.textVal.addWidget(self.__textTolerance)
        self.textVal.addWidget(self.l4)
        self.textVal.addWidget(self.__go2)
        
        
        self.mainLO = QVBoxLayout()
        self.mainLO.addLayout(self.selectBand)
        self.mainLO.addWidget(self.l1)
        self.mainLO.addLayout(self.selCol)
        self.mainLO.addWidget(self.l2)
        self.mainLO.addLayout(self.textVal)
        self.mainLO.addWidget(self.resViewer)
        self.setLayout(self.mainLO)


        self.connect(self.__4band,
                SIGNAL("stateChanged(int)"),
                self._4bandChecked)
        self.connect(self.__5band,
                SIGNAL("stateChanged(int)"),
                self._5bandChecked)

        self.connect(self.__credit,
                     SIGNAL("clicked()"),
                     self.showCredit)

        self.connect(self.__go1,
                     SIGNAL("clicked()"),
                     self.show_byCol)
        self.connect(self.__go2,
                     SIGNAL("clicked()"),
                     self.show_byVal)


    def _4bandChecked(self,state) :
        if state==Qt.Checked :
            self.__5band.setChecked(False)
            self.resViewer.is4band=True
            self.__5thColor.setEnabled(False)

    def _5bandChecked(self,state) :
        if state==Qt.Checked :
            self.__4band.setChecked(False)
            self.resViewer.is4band=False
            self.__5thColor.setEnabled(True)

    def show_byCol(self):
        if self.__4band.checkState() == Qt.Checked :
            getVal = self.colToVal(indexes = [self.__1stColor.currentIndex(),
                                              self.__2ndColor.currentIndex(),
                                              self.__3rdColor.currentIndex(),
                                              self.__4thColor.currentIndex()])
            self.__textValue.setText(QString.number(getVal[0]))
            self.__textTolerance.setText(QString.number(getVal[1]))
            self.resViewer.colors = [colors.Colors[self.__1stColor.currentIndex()],
                                    colors.Colors[self.__2ndColor.currentIndex()],
                                    colors.Colors[self.__3rdColor.currentIndex()],
                                    colors.Colors[self.__4thColor.currentIndex()]]
        if self.__5band.checkState() == Qt.Checked :
            getVal = self.colToVal(indexes = [self.__1stColor.currentIndex(),
                                              self.__2ndColor.currentIndex(),
                                              self.__3rdColor.currentIndex(),
                                              self.__4thColor.currentIndex(),
                                              self.__5thColor.currentIndex()])
            self.__textValue.setText(QString.number(getVal[0]))
            self.__textTolerance.setText(QString.number(getVal[1]))
            self.resViewer.colors = [colors.Colors[self.__1stColor.currentIndex()],
                                     colors.Colors[self.__2ndColor.currentIndex()],
                                     colors.Colors[self.__3rdColor.currentIndex()],
                                     colors.Colors[self.__4thColor.currentIndex()],
                                     colors.Colors[self.__5thColor.currentIndex()]]

   
    def show_byVal(self):
        if self.__4band.checkState() == Qt.Checked :
            if len(str(self.__textValue.text())) < 2:
                QMessageBox.warning(self,
                                    "Error",
                                    "Wrong Value typed")
            else :
                if colors.Tolerance[self.__4thColor.currentIndex()] != None :
                    valueStr =str(self.__textValue.text())
                    _1stColIndex = int(valueStr[0])
                    _2ndColIndex = int(valueStr[1])
                    _3rdColIndex = len(str(self.__textValue.text())) - 2
                    _4thColIndex = self.__4thColor.currentIndex()
                    self.__textTolerance.setText(QString.number(colors.Tolerance[_4thColIndex]))
                    self.resViewer.colors = [colors.Colors[_1stColIndex],
                                             colors.Colors[_2ndColIndex],
                                             colors.Colors[_3rdColIndex],
                                             colors.Colors[_4thColIndex]]
                else :
                    QMessageBox.warning(self,
                                    "Error",
                                    "Wrong Color for the 4th band")
        if self.__5band.checkState() == Qt.Checked :
            if len(str(self.__textValue.text())) < 3:
                QMessageBox.warning(self,
                                    "Error",
                                    "Wrong Value typed")
            else :
                if colors.Tolerance[self.__5thColor.currentIndex()] != None :
                    valueStr =str(self.__textValue.text())
                    _1stColIndex = int(valueStr[0])
                    _2ndColIndex = int(valueStr[1])
                    _3rdColIndex = int(valueStr[2])                    
                    _4thColIndex = len(str(self.__textValue.text())) - 3
                    _5thColIndex = self.__5thColor.currentIndex()
                    self.__textTolerance.setText(QString.number(colors.Tolerance[_5thColIndex]))
                    self.resViewer.colors = [colors.Colors[_1stColIndex],
                                             colors.Colors[_2ndColIndex],
                                             colors.Colors[_3rdColIndex],
                                             colors.Colors[_4thColIndex],
                                             colors.Colors[_5thColIndex]]
                else :
                    QMessageBox.warning(self,
                                    "Error",
                                    "Wrong Color for the 5th band")
        

    def showCredit(self):
        QMessageBox.about(self,
                          "Resistor Viewer 3D",
                          "Resistor Viewer 3D\n\n\n"+
                          "Author   :   Asif Mahmud Shimon\n"+
                          "Year     :   2012\n"+
                          "             EEE 09\n"+
                          "             Member of RUET Olympiad Society ")

    def colToVal(self,indexes):
        if len(indexes)==4:
            value = (indexes[1]+10*indexes[0])*colors.Multiplier[indexes[2]]            
            if colors.Tolerance[indexes[3]] != None :
                tolerance = colors.Tolerance[indexes[3]]
            else :
                QMessageBox.warning(self,
                                    "Error",
                                    "Wrong Color for the 4th band")
                tolerance =0
            return [value,tolerance]
        if len(indexes)==5:
            value = (indexes[2]+10*indexes[1]+100*indexes[0])*colors.Multiplier[indexes[3]]            
            if colors.Tolerance[indexes[4]] != None :
                tolerance = colors.Tolerance[indexes[4]]
            else :
                QMessageBox.warning(self,
                                    "Error",
                                    "Wrong Color for the 5th band")
                tolerance =0
            return [value,tolerance]
