
class colors():
    Brown = [165,42,42]
    Black = [0,0,0]
    Red   = [255,0,0]
    Orange = [255,128,0]
    Yellow = [255,255,0]
    Green = [0,255,0]
    Blue  = [0,0,255]
    Violet = [238,130,238]
    Grey  = [128,128,128]
    White  = [255,255,255]
    Gold = [255,215,0]
    Silver = [192,192,192]

    Colors = [Black,
              Brown,
              Red,
              Orange,
              Yellow,
              Green,
              Blue,
              Violet,
              Grey,
              White,
              Gold,
              Silver]
    ColorNames1 = ["Black",
                   "Brown",
                   "Red",
                   "Orange",
                   "Yellow",
                   "Green",
                   "Blue",
                   "Violet",
                   "Grey",
                   "White"]
    ColorNames2 = ["Black",
                   "Brown",
                   "Red",
                   "Orange",
                   "Yellow",
                   "Green",
                   "Blue",
                   "Violet",
                   "Grey",
                   "White",
                   "Gold",
                   "Silver"]
    Multiplier = [1,
                  10,
                  100,
                  1000,
                  10000,
                  100000,
                  1000000,
                  10000000,
                  100000000,
                  1000000000,
                  0.1,
                  0.01]
    Tolerance = [None,
                 1,
                 2,
                 3,
                 4,
                 0.5,
                 0.25,
                 0.10,
                 0.05,
                 None,
                 5,
                 10]
    


    
