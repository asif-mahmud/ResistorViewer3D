from OpenGL.GL import *
from gl_util.gl_util import gl_util

class Res_4band():
    '''contains function to draw 4 band resistor'''
    def draw_4band_res(self,colors=[[155,155,155],[155,155,155],[155,155,155],[155,155,155]]):
        glUtil = gl_util()

        glPushMatrix()
        glTranslatef(-40,0,0)
        glUtil.draw_cylinder(1,85,10,color=[166,165,164])
        glPopMatrix()

        glPushMatrix()
        glTranslatef(-30,0,0)
        glUtil.draw_cone(10,5,0.1,color=[219,216,186])
        glPopMatrix()

        #first band
        glPushMatrix()
        glTranslatef(-25,0,0)
        glUtil.draw_cylinder(10,5,20,color=colors[0])
        glPopMatrix()

        
        glPushMatrix()
        glTranslatef(-15,0,0)
        glUtil.draw_cone_neg(10,5,0.1,color=[219,216,186])
        glPopMatrix()


        glPushMatrix()
        glTranslatef(20,0,0)
        glUtil.draw_cone(10,5,0.1,color=[219,216,186])
        glPopMatrix()
        
        #4th band
        glPushMatrix()
        glTranslatef(25,0,0)
        glUtil.draw_cylinder(10,5,20,color=colors[3])
        glPopMatrix()

        glPushMatrix()
        glTranslatef(35,0,0)
        glUtil.draw_cone_neg(10,5,0.1,color=[219,216,186])
        glPopMatrix()


        glPushMatrix()
        glTranslatef(-18,0,0)
        glUtil.draw_cylinder(7,8,20,color=[219,216,186])
        glPopMatrix()

        #2nd band
        glPushMatrix()
        glTranslatef(-10,0,0)
        glUtil.draw_cylinder(7,5,20,color=colors[1])
        glPopMatrix()

        glPushMatrix()
        glTranslatef(-5,0,0)
        glUtil.draw_cylinder(7,10,20,color=[219,216,186])
        glPopMatrix()


        #3rd band
        glPushMatrix()
        glTranslatef(5,0,0)
        glUtil.draw_cylinder(7,5,20,color=colors[2])
        glPopMatrix()

        glPushMatrix()
        glTranslatef(10,0,0)
        glUtil.draw_cylinder(7,15,20,color=[219,216,186])
        glPopMatrix()
