from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtOpenGL import *
from OpenGL.GL import *
from OpenGL.GLU import *
import sys,math


class gl_util():
    '''includes circle,cone,cylinder'''
    def draw_circle(self,radius ,segments,color=[158,125,164]):
        '''draws a circle of the given radius and segments with color[R,G,B]
            along the x-axis'''
        angle =0.0
        glPolygonMode(GL_FRONT_AND_BACK,GL_FILL)
	glBegin(GL_POLYGON)
	glColor3ub(color[0],color[1],color[2])
	while angle<2*3.1415 :
            glVertex2f(radius*math.cos(angle),radius*math.sin(angle))
            glVertex2f(radius*math.cos(angle+((2*3.1415)/segments)),radius*math.sin(angle+((2*3.1415)/segments)))
	    angle+=((2*3.1415)/segments)
	glEnd()
	glPolygonMode(GL_FRONT_AND_BACK,GL_LINE)


    def draw_cylinder(self ,radius ,height,segments,color=[156,125,255]):
        '''draws a cylinder of the given radius and height and segments with color[R,G,B]
            along the x-axis'''  
	angle =0.0	
	glPolygonMode(GL_FRONT_AND_BACK,GL_FILL)	
	glBegin(GL_POLYGON)
	glColor3ub(color[0],color[1],color[2])
	while angle<2*3.1415 :
            angle+=((2*3.1415)/segments)
            glVertex3f(0,radius*math.cos(angle),radius*math.sin(angle))
            glVertex3f(0,radius*math.cos(angle+((2*3.1415)/segments)),radius*math.sin(angle+((2*3.1415)/segments)))
	    glVertex3f(0,radius*math.cos(angle),radius*math.sin(angle))
            glVertex3f(height,radius*math.cos(angle),radius*math.sin(angle))
            glVertex3f(0,radius*math.cos(angle+((2*3.1415)/segments)),radius*math.sin(angle+((2*3.1415)/segments)))
            glVertex3f(height,radius*math.cos(angle+((2*3.1415)/segments)),radius*math.sin(angle+((2*3.1415)/segments)))
            glVertex3f(height,radius*math.cos(angle),radius*math.sin(angle))
            glVertex3f(height,radius*math.cos(angle+((2*3.1415)/segments)),radius*math.sin(angle+((2*3.1415)/segments)))
	
	glEnd()
	glPolygonMode(GL_FRONT_AND_BACK,GL_LINE)

    def draw_cone(self,radius,height,segmentOffset,color=[128,35,142]):
        '''draws a cone of the given radius and height and segmentOffset with color[R,G,B]
            along the x-axis'''
        angle = 0.0
        glPolygonMode(GL_FRONT_AND_BACK,GL_FILL)
        glColor3ub(color[0],color[1],color[2])
        glBegin(GL_TRIANGLE_FAN)
        glVertex2f(0,0)
        while angle<(2*3.1415):            
            glVertex3f(height,radius*math.cos(angle),radius*math.sin(angle))
            angle+=segmentOffset
        glVertex3f(height,radius*math.cos(2*3.1415),math.sin(2*3.1415))
        glEnd()
        
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE)

    def draw_cone_neg(self,radius,height,segmentOffset,color=[128,35,142]):
        '''draws a cone of the given radius and height and segmentOffset with color[R,G,B]
            along the x-axis'''
        angle = 0.0
        glPolygonMode(GL_FRONT_AND_BACK,GL_FILL)
        glColor3ub(color[0],color[1],color[2])
        glBegin(GL_TRIANGLE_FAN)
        glVertex2f(0,0)
        while angle<(2*3.1415):            
            glVertex3f(-height,radius*math.cos(angle),radius*math.sin(angle))
            angle+=segmentOffset
        glVertex3f(-height,radius*math.cos(2*3.1415),math.sin(2*3.1415))
        glEnd()
        
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE)



    
        
