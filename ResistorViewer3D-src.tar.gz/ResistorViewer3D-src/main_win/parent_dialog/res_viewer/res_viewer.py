from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtOpenGL import *
from OpenGL.GL import *
from OpenGL.GLU import *
import sys,math

from models.Res_4band import Res_4band
from models.Res_5band import Res_5band

class ResViewer(QGLWidget):

    def __init__(self,Colors=None,parent =None):
        super(ResViewer,self).__init__(parent)        
        self.setMinimumSize(400,400)
        self.setMaximumSize(400,400)
        self.window_w = 400
        self.window_h = 400
        self.fovi = 45.0
        self.zNear = 1.0
        self.zFar = 600.0
        self.timer = QTimer()
        self.rotX = 0.0
        self.rotY = 0.0
        self.rotZ = 0.0       
        self.ySpeed = 2
        self._4band = Res_4band()
        self._5band = Res_5band()
        self.is4band = True
        self.colors = Colors
        self.connect(
            self.timer,
            SIGNAL("timeout()"),
            self.animate)


    def initializeGL(self):
        glClearColor(1,1,1,0.0)
        glShadeModel(GL_SMOOTH)        
        self.timer.start(50)
        

    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        
        glMatrixMode(GL_MODELVIEW)
	glLoadIdentity()
	
	glTranslatef(0.0,0.0,-150)
	
        #glRotatef(self.rotY,1,0,0)
        glRotatef(self.rotY,0,1,0)
        
        glPushMatrix()

        if self.is4band :
            if self.colors == None :
                self._4band.draw_4band_res()
            else :
                if len(self.colors) == 4 :
                    self._4band.draw_4band_res(self.colors)
                else:
                    self._4band.draw_4band_res()
                
        else :
            if self.colors == None :
                self._5band.draw_5band_res()
            else :
                if len(self.colors) == 5 :
                    self._5band.draw_5band_res(self.colors)
                else:
                    self._5band.draw_5band_res()
        
        glPopMatrix()

    def resizeGL(self,w,h):
        self.window_w = w
        self.window_h = h
        glViewport(0,0,self.window_w,self.window_h)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(self.fovi,
                       self.window_w/self.window_h,
                       self.zNear,
                       self.zFar)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

    def animate(self):
        self.rotY+=self.ySpeed
        self.updateGL()


