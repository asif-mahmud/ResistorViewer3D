Resistor Viewer 3-D v1.0.0
==============================

Author	: 	Asif Mahmud Shimon
		EEE 09
		Member of Ruet Olympiad Society

mail	:	mailtoshimon@gmail.com



Features 
==============================

An utility software which can show 
Resistors graphically and 3-D by simply
putting the resistor's value or
the color bands sequentially.