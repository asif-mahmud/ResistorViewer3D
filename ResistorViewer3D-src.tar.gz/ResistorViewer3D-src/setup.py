from cx_Freeze import setup, Executable

includes = ["sip","re","atexit","PyQt4"]

setup(
    name = "ResistorViewer3D",
    version = "1.0.0",
    description = "Graphically view various valued resistors",
    author = "Asif Mahmud Shimon",
    executables = [Executable(
        script="Resistor-Viewer.pyw",
        base="Win32GUI")],
    options = {"build_exe" : {"includes" : includes,
                              "icon":"icon.ico",
                              "include_files":["icon.png",
                                               "icon.ico",
                                               "glut32.dll",
                                               "gpl-3.0.txt",
                                               "README.txt"]}})
